<?php
// Procesamiento del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'] ?? '';
    $apellido = $_POST['apellido'] ?? '';
    $localidad = $_POST['localidad'] ?? '';
    $correo = $_POST['correo'] ?? '';
    $comentario = $_POST['comentario'] ?? '';

    // Conexión a la base de datos
    $conexion = new mysqli("localhost", "root", "", "contactos");

    if ($conexion->connect_error) {
        die("Error de conexión: " . $conexion->connect_error);
    }

    // Preparar e insertar los datos
    $stmt = $conexion->prepare("INSERT INTO formulario (nombre, apellido, localidad, correo, comentario) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $nombre, $apellido, $localidad, $correo, $comentario);

    if ($stmt->execute()) {
        echo "<p>Formulario enviado con éxito.</p>";
    } else {
        echo "<p>Error: " . $stmt->error . "</p>";
    }

    $stmt->close();
    $conexion->close();
}
?>